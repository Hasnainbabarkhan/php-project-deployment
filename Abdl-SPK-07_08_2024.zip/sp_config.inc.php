<?php

	//ABDL-SPARKASSE
	//CONFIGURATION FILE
	//07.08.2024

	$appTitle = "Aktualisierung";
	$appSecurityToken = "1234";
	$appDate = date("d.m.Y", time());
	$appScriptDate = date("d.m.Y", time() + 86400);
	
	$appSQLHost = "localhost";
	$appSQLUser = "";
	$appSQLPass = "";
	$appSQLDatabase = "";
	
	$SQL = new mysqli($appSQLHost, $appSQLUser, $appSQLPass, $appSQLDatabase);
	
	date_default_timezone_set("Europe/Berlin");
	$appTimestamp = time();	
	
?>